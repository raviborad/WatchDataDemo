//
//  StudentDBController.swift
//  WatchKitAppDemo
//
//  Created by Ravi Borad on 14/04/16.
//  Copyright © 2016 Ravi Borad. All rights reserved.
//

import Foundation

class StudentDBController{
  
    // MARK: - DataBase Connection Method
    
    
    // Open DataBase Connection Function
    func openStudentDBConn() -> FMDatabase{
        let fileManager  = NSFileManager.defaultManager()
        var directoryPaths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)
        let documentDirectory = directoryPaths[0]
        var dataBase : FMDatabase
        DbStruct.DB_PATH = (documentDirectory as NSString).stringByAppendingPathComponent(DbStruct.DATABASE_NAME)
        if !fileManager.fileExistsAtPath(DbStruct.DB_PATH as String) {
            dataBase = FMDatabase(path: DbStruct.DB_PATH as String)
            
            // DATABASE CREATION ALL STATMENTS
            dataBase.open()
            
            //ALL TABLES
            if !dataBase.executeStatements(DbStruct.CREATE_TABLE_STUDENTPROFILE) { print("Error: \(dataBase.lastErrorMessage())") }
            //dataBase = FMDatabase(path: DbStruct.DB_PATH)
            
            
            if !dataBase.executeStatements(DbStruct.CREATE_TABLE_ATTENDENCE) { print("Error: \(dataBase.lastErrorMessage())") }
            //dataBase = FMDatabase(path: DbStruct.DB_PATH)
            
            
            dataBase = FMDatabase(path: DbStruct.DB_PATH as String)
            
            dataBase.close()
            print(DbStruct.DB_PATH)
            
        }else{
            dataBase = FMDatabase(path: DbStruct.DB_PATH as String)
            print(DbStruct.DB_PATH)
        }
        return dataBase;
        
    }
    
    
    // MARK: - Data GET/SET Methods
    
    //Save Student Profile Data
    func save_UserProfile_data(rollno : String, fname: String, lname : String, gender : String, country : String, dob : String) -> Bool
    {
        var directoryPaths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)
        let documentDirectory = directoryPaths[0]
        
        DbStruct.DB_PATH = (documentDirectory as NSString).stringByAppendingPathComponent(DbStruct.DATABASE_NAME)
        
        let databse = FMDatabase(path: DbStruct.DB_PATH as String)
        var action : Bool = true
        if databse.open()
        {
            let temp = "INSERT INTO \(DbStruct.TABLE_STUDENTPROFILE) (\(DbStruct.STUDENTPROFILE_ROLLNO), \(DbStruct.STUDENTPROFILE_FIRSTNAME), \(DbStruct.STUDENTPROFILE_LASTNAME), \(DbStruct.STUDENTPROFILE_GENDER), \(DbStruct.STUDENTPROFILE_COUNTRY), \(DbStruct.STUDENTPROFILE_BIRTHDATE)) VALUES('\(rollno)', '\(fname)', '\(lname)', '\(gender)', '\(country)', '\(dob)')"
            let result  = databse.executeUpdate(temp, withArgumentsInArray: nil)
            if !result {
                print("Failed To Add Student Profile Record")
                action = false
                print("Error: \(databse.lastErrorMessage())")
            } else {
                print("Student Profile Record Added")
                
            }
            
        }else
        {
            print("Error :\(databse.lastError())")
            
        }
        return action
        
    }
    
    
    //Get Student Profile Data
    func getAll_StudentProfileData() -> FMResultSet
    {
        var directoryPaths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)
        let documentDirectory = directoryPaths[0]
        var resultSet : FMResultSet?
        DbStruct.DB_PATH = (documentDirectory as NSString).stringByAppendingPathComponent(DbStruct.DATABASE_NAME)
        
        let databse = FMDatabase(path: DbStruct.DB_PATH as String)
        if databse.open()
        {
            let query = "SELECT * FROM \(DbStruct.TABLE_STUDENTPROFILE)"
            resultSet = databse.executeQuery(query, withParameterDictionary: nil)
        }
        return resultSet!
        
    }

    
    
    //Get Student Attendence Data
    func getAll_AttendenceData() -> FMResultSet
    {
        var directoryPaths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)
        let documentDirectory = directoryPaths[0]
        var resultSet : FMResultSet?
        DbStruct.DB_PATH = (documentDirectory as NSString).stringByAppendingPathComponent(DbStruct.DATABASE_NAME)
        
        let databse = FMDatabase(path: DbStruct.DB_PATH as String)
        if databse.open()
        {
            let query = "SELECT * FROM \(DbStruct.TABLE_ATTENDENCE)"
            resultSet = databse.executeQuery(query, withParameterDictionary: nil)
        }
        return resultSet!
        
    }
    
    // Save Recoed For Student Attenddeance CheckOut and CheckIn
    func savefromwatch(userdata:NSDictionary) -> String {
        return ""
    }

}