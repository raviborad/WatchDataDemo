//
//  StudentDBStructure.swift
//  WatchKitAppDemo
//
//  Created by Ravi Borad on 14/04/16.
//  Copyright © 2016 Ravi Borad. All rights reserved.
//

import Foundation

struct DbStruct{
    
    static  var DATABASE_NAME = "STUDENT.DB"
    
    //Table : STUDENT RAB+8+5+15
    
    static  var TABLE_STUDENTPROFILE       = "STUDENTPROFILE_TB"
    static  let STUDENTPROFILE_ROLLNO      = "ROLLNO"
    static  let STUDENTPROFILE_FIRSTNAME   = "FIRSTNAME"
    static  let STUDENTPROFILE_LASTNAME    = "LASTNAME"
    static  let STUDENTPROFILE_GENDER      = "GENDER"
    static  let STUDENTPROFILE_COUNTRY     = "COUNTRY"
    static  let STUDENTPROFILE_BIRTHDATE   = "BIRTHDATE"
    
    
    
    
    static let DROP_TABLE_STUDENTPROFILE  = "DROP TABLE IF EXISTS " + TABLE_STUDENTPROFILE
    
    static let CREATE_TABLE_STUDENTPROFILE = "CREATE TABLE IF NOT EXISTS "
        + TABLE_STUDENTPROFILE         + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, "
        + STUDENTPROFILE_ROLLNO        + " TEXT, "
        + STUDENTPROFILE_FIRSTNAME     + " TEXT, "
        + STUDENTPROFILE_LASTNAME      + " TEXT, "
        + STUDENTPROFILE_GENDER        + " TEXT,"
        + STUDENTPROFILE_COUNTRY       + " TEXT,"
        + STUDENTPROFILE_BIRTHDATE     + " TEXT)"
    
    
    
    
    //Table : ATTENDENCE RAB+8+5+15
    
    static  var TABLE_ATTENDENCE        = "ATTENDENCE_TB"
    static  let ATTENDENCE_DATETIME     = "DATETIME"
    static  let ATTENDENCE_CHECKINTIME     = "CHECKINTIME"
    static  let ATTENDENCE_CHECKOUTTIME     = "CHECKOUTTIME"
    static  let ATTENDENCE_ISPRESENT    = "ISPRESENT"
    
    
    
    static let DROP_TABLE_ATTENDENCE  = "DROP TABLE IF EXISTS " + TABLE_ATTENDENCE
    
    static let CREATE_TABLE_ATTENDENCE = "CREATE TABLE IF NOT EXISTS "
        + TABLE_ATTENDENCE               + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, "
        + ATTENDENCE_DATETIME            + " TEXT,"
        + ATTENDENCE_CHECKINTIME         + " TEXT,"
        + ATTENDENCE_CHECKOUTTIME        + " TEXT,"
        + ATTENDENCE_ISPRESENT           + " TEXT)"
    
    
    static var DB_PATH : NSString = ""
}