//
//  StudentProfileVC.swift
//  WatchKitAppDemo
//
//  Created by Ravi Borad on 14/04/16.
//  Copyright © 2016 Ravi Borad. All rights reserved.
//

import UIKit


struct StructStudentData {
    
    static var value = ""
    static var uct : Int = 0
    
    
    static var rollnumbervalue = ""
    static var fnamevalue = ""
    static var lnamevalue = ""
    static var gendervalue = ""
    static var countryvalue = ""
    static var birthdatevalue = ""
    
    static var loaddate = ""
    static var editdate = ""
    static var checkdate = ""
    
}


class StudentProfileVC: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var txtrollno: UITextField!
    @IBOutlet weak var txtfirstname: UITextField!
    @IBOutlet weak var txtlastname: UITextField!
    @IBOutlet weak var txtcountry: UITextField!
    @IBOutlet weak var txtdate: UITextField!
    
    @IBOutlet weak var btnedit: UINavigationItem!
    @IBOutlet weak var segment_Gender: UISegmentedControl!
    
    @IBOutlet weak var datepickerDOB: UIDatePicker!
    @IBOutlet weak var viewdate: UIView!
    
    @IBOutlet weak var btnsave: UIButton!
    @IBOutlet weak var btnreset: UIButton!
    
    
    var strct : DbStruct?
    var mydata : FMDatabase?
    var obj : StudentDBController?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        obj = StudentDBController()
        strct = DbStruct()
        obj?.openStudentDBConn()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
// MARK: - Custome methods
    
    @IBAction func ActionSaveProfileData(sender: AnyObject) {
        
        if txtrollno.text != "" && txtfirstname.text != "" && txtlastname.text != "" && txtdate.text != "" && txtcountry.text != ""
        {            
            
            let result = obj?.save_UserProfile_data(txtrollno.text!, fname: txtfirstname.text!, lname: txtlastname.text!, gender: StructStudentData.gendervalue, country: txtcountry.text!, dob: txtdate.text!)
            let myalert = UIAlertView()
            myalert.title = "Successfully!"
            myalert.message = "User Profile Record Inserted"
            myalert.addButtonWithTitle("Ok")
            myalert.show()
            
            if result == true
            {
                txtcountry.text = ""
                txtdate.text = ""
                txtfirstname.text = ""
                txtlastname.text = ""
                segment_Gender.selectedSegmentIndex = 0
                
            }
            else
            {
                let myalert = UIAlertView()
                myalert.title = "Error In Insert"
                myalert.message = "Unable To Insert Student Profile Record!"
                myalert.addButtonWithTitle("OK")
                myalert.show()
            }
        }
        else
        {
            let myalert = UIAlertView()
            myalert.title = "Warnning"
            myalert.message = "Enter the value in field"
            myalert.addButtonWithTitle("Got it?")
            myalert.show()
            
        }
    }
    
    
    @IBAction func ActionCancelDate(sender: AnyObject) {
        viewdate.hidden = true
        txtdate.hidden = false
        txtcountry.hidden = false
        segment_Gender.hidden = false
        if  txtdate.text != "" {
            
        }else {
            self.txtdate.text = ""
            txtdate.hidden = false
            txtcountry.hidden = false
            segment_Gender.hidden = false
            
        }
        
    }
    
    var dddate = ""
    var now = NSDate()
    var yearStr = ""
    
    @IBAction func ActionFillDate(sender: AnyObject) {
        let dateFormatter = NSDateFormatter()
        
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        let Date = dateFormatter.stringFromDate(datepickerDOB.date)
        self.txtdate.text = Date
        dddate = Date
        
        
        let strdob = dddate
        
        
        
        let rangeOfYear = Range(start: (strdob.endIndex.advancedBy(-4)),
            end: strdob.endIndex)
        yearStr = strdob.substringWithRange(rangeOfYear)
        print("DOB Year = " + yearStr)
        
        
        let flags: NSCalendarUnit = [.NSDayCalendarUnit, .NSMonthCalendarUnit, .NSYearCalendarUnit]
        let date = NSDate()
        let components = NSCalendar.currentCalendar().components(flags, fromDate: date)
        //println("System Date = " + "\(date)")
        
        let year = components.year
        print("Current Year = " + "\(year)")
        var month = components.month
        //println("Month = " + "\(month)")
        var day = components.day
        //println("Day = " + "\(day)")
        
        
        
//        age =  year - Int(yearStr)!
        
        //println("Age = " + "\(age)")
        
        
        txtdate.hidden = false
        txtcountry.hidden = false
        segment_Gender.hidden = false
        
        
        
        
        viewdate.hidden = true
        
    }
    
    
    @IBAction func ActionSelectGender(sender: AnyObject) {
        if sender.selectedSegmentIndex == 0 {
            print("Male")
            StructStudentData.gendervalue = "Male"
            
        }else if sender.selectedSegmentIndex == 1{
            
            print("Female")
            StructStudentData.gendervalue = "Female"
        }else {
            print("Defult Male")
            StructStudentData.gendervalue = "Male"
        }
    }
    
    

    
}
